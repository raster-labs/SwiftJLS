#!/usr/bin/env python3
import ast,datetime,hashlib,json,pathlib,re,subprocess,zipfile
ROOT=pathlib.Path('/private/tmp/swiftjls-m5-ci-16adfe06')
REPO=pathlib.Path('/Users/pushparaj/projects/SwiftJLS-milestone5')
HEAD='16adfe068c3913f35b9cc72e3006be5a152d7665'
def sha(data): return hashlib.sha256(data).hexdigest()
def load(p):return json.loads(p.read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def check(condition,message):
 if not condition:raise ValueError(message)
report={'head':HEAD,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','artifacts':[],'preparation':[],'discrepancies':[], 'audit_script_sha256':sha(pathlib.Path(__file__).read_bytes()),'prior_audit_attempt':'Attempt1 stopped on an audit-script assumption that every CLI payload row had an expected key. Three condition rows instead have expected codes defined by the pinned test script. This was an audit harness error. Attempt2 incorrectly required byte-identical host/Linux demangling of all unrelated symbols. The final audit preserves independent demangling, verifies all allocation row counts and requires exact injected-stack equality. Both prior scripts and receipts are retained.'}
try:
 check(git('rev-parse',HEAD).decode().strip()==HEAD,'Git object unavailable')
 tree=git('rev-parse',HEAD+'^{tree}').decode().strip()
 downloads=load(ROOT/'downloads.json')
 for name in ['release-preparation-swift-6.2','release-preparation-swift-6.4','cross-codec-copy-mutation']:
  row=next(x for x in downloads if x['name']==name)
  archive=ROOT/(name+'.zip');body=archive.read_bytes()
  check(sha(body)==row['digest'].removeprefix('sha256:'),name+' archive digest differs')
  check(len(body)==row['bytes'],name+' archive size differs')
  count=0
  with zipfile.ZipFile(archive) as z:
   for info in z.infolist():
    if info.is_dir():continue
    check((ROOT/name/info.filename).read_bytes()==z.read(info),name+' extracted bytes differ: '+info.filename)
    count+=1
  report['artifacts'].append({**row,'archive_sha256_verified':True,'extracted_files_byte_verified':count})
 for version,engine in [('6.2','native'),('6.4','swiftbuild')]:
  p=ROOT/('release-preparation-swift-'+version)/'swiftjls-preparation';d=load(p/'report.json')
  check(d['status']=='passed' and d['release_ready'] is False and d['not_run']==[],'Preparation status mismatch')
  check(d['revision']==HEAD and d['source_tree']==tree and d['build_engine']==engine,'Preparation identity mismatch')
  check(d['suite_policy']=='0.10.0' and d['version']=='1.1.0-dev.2','Policy/version mismatch')
  check(len(d['commands'])==23 and len({x['label'] for x in d['commands']})==23,'Wrong command set')
  for command in d['commands']:
   check(command['exit_code']==0,'Failed command: '+command['label'])
   for key in ['stdout','stderr']:check((p/command[key]).is_file(),'Missing command log')
   if '--build-system' in command['argv']:
    check(command['argv'][command['argv'].index('--build-system')+1]==engine,'Wrong actual engine')
  check((p/'source-revision.stdout.log').read_text().strip()==HEAD and (p/'candidate-final-revision.stdout.log').read_text().strip()==HEAD,'Raw revision log mismatch')
  check((p/'source-tree.stdout.log').read_text().strip()==tree,'Raw tree log mismatch')
  check((p/'source-status.stdout.log').read_bytes()==b'' and (p/'candidate-final-status.stdout.log').read_bytes()==b'','Dirty source log')
  check((p/'swift-version.stdout.log').read_text().strip()==d['compiler'],'Compiler log mismatch')
  check(len(d['inputs'])==9,'Wrong committed input count')
  for path,digest in d['inputs'].items():check(sha(git('show',HEAD+':'+path))==digest,'Committed input differs: '+path)
  check((p/'candidate/Package.swift').read_bytes()==git('show',HEAD+':Package.swift'),'Retained manifest differs')
  check(len(d['consumers'])==2,'Wrong consumer count')
  for consumer in d['consumers']:
   label=consumer['label'];locked=load(p/label/'Package.resolved')['pins']
   check(len(locked)==1 and locked[0]==consumer['pin'],'Lock/report differs')
   pin=locked[0];check(pin['identity']=='swiftjls' and pin['state']['revision']==HEAD,'Wrong exact lock')
   check(consumer['status']=='passed' and consumer['examples']==['Consumer','ReadmeExample','MigrationExample'],'Consumer coverage differs')
   if label=='hosted-revision':check(pin['kind']=='remoteSourceControl' and pin['location']=='https://github.com/raster-labs/SwiftJLS.git' and set(pin['state'])=={'revision'},'Hosted pin is not exact remote revision')
   else:check(label=='local-semver' and pin['kind']=='localSourceControl' and pin['state']['version']=='1.1.0-dev.2','Rehearsal lock differs')
  process=load(p/'cli-process/report.json');payload=load(p/'cli-payload.json')
  check(process['status']=='passed' and process['checks']==len(process['commands'])==103,'CLI process count/status')
  check(all(c['exit_code']==c['expected_exit_code'] for c in process['commands']),'CLI process exit mismatch')
  check(len(payload)==73 and all(c['exit']==(c['expected'] if 'expected' in c else {'deadline blocked pipe':5,'cancel blocked pipe':130,'closed binary output':6}.get(c.get('condition'))) for c in payload),'CLI payload count/exit mismatch')
  for field,path in [('test_runner_sha256','Scripts/test-cli.py'),('installer_sha256','Scripts/install-cli.sh'),('manual_sha256','ManPages/swiftjls-cli.1')]:
   check(process[field]==sha(git('show',HEAD+':'+path)),'CLI support-source hash mismatch: '+path)
  check(d['repository_tags_unchanged'] is True,'Tag preservation not passed')
  # Pinned harness checks the source tag state before/after; it emits a rehearsal
  # tag only in its fresh temporary bare clone. CI did not retain separate tag logs.
  prepare=git('show',HEAD+':Scripts/ReleasePreparation/prepare.py').decode()
  check('tags_after.stdout != tags_before' in prepare and 'report["repository_tags_unchanged"] = True' in prepare,'Pinned tag assertion missing')
  tag=next(x for x in d['commands'] if x['label']=='rehearsal-tag')['argv']
  check(tag==['git','--git-dir','/tmp/swiftjls-preparation/SwiftJLS.git','tag','v1.1.0-dev.2',HEAD],'Tag action escaped temporary clone')
  provenance=load(p.parent/'swiftjls-provenance.json');controls=load(p.parent/'swiftjls-provenance-controls.json')
  check(provenance['status']=='passed' and provenance['source_revision']==HEAD and provenance['counts']['errors']==0,'Provenance gate failed')
  check(controls['status']=='passed' and len(controls['controls'])==11 and all(c['passed'] for c in controls['controls']),'Provenance controls failed')
  report['preparation'].append({'compiler':d['compiler'],'engine':engine,'commands':23,'all_commands_exit_zero':True,'inputs_verified':9,'exact_locks_verified':2,'cli_process_checks':103,'cli_payload_checks':73,'cli_support_source_hashes_verified':3,'source_tags_unchanged':True,'tag_evidence_scope':'Pinned executed harness before/after assertion and temporary-clone tag argv; no separately retained tag-state logs','provenance_counts':provenance['counts'],'provenance_controls':11,'report_sha256':sha((p/'report.json').read_bytes())})
 p=ROOT/'cross-codec-copy-mutation';d=load(p/'summary.json');trace=load(p/'mutant/summary.json')
 check(all(x['exit_code']==0 for x in d['commands']) and len(d['commands'])==2,'Mutation build/trace failure')
 check(all(x['exit_code']==0 for x in trace['commands']) and len(trace['commands'])==3,'Heaptrace command failure')
 check(sha((p/'mutant'/trace['profile']).read_bytes())==trace['profile_sha256'],'Heap profile digest mismatch')
 original=git('show',HEAD+':Sources/SwiftJLS/JPEGLS/ScalarCodec.swift').decode()
 source=git('show',HEAD+':Scripts/StorageEvidence/mutate-copy.py').decode()
 parsed=ast.parse(source);main=next(x for x in parsed.body if isinstance(x,ast.FunctionDef) and x.name=='main')
 constants={x.targets[0].id:ast.literal_eval(x.value) for x in main.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and isinstance(x.value,ast.Constant)}
 needle=constants['needle'];helper=constants['helper'];check(original.count(needle)==1,'Mutation boundary not unique')
 mutant=original.replace(needle,helper+needle+'        let image = try telemetryInjectedFrameCopy(image, limits: options.resourceLimits)\n')
 check(sha(original.encode())==d['source_sha256'] and sha(mutant.encode())==d['mutated_sha256'],'Original/mutated source digest mismatch')
 rawstacks=(p/'mutant/allocation-stacks.txt').read_bytes()
 demangle=subprocess.run(['swift','demangle'],input=rawstacks,capture_output=True,check=True).stdout.decode()
 retained=(p/'mutant/allocation-stacks-demangled.txt').read_text()
 check([line.rsplit(';',1)[1] for line in demangle.splitlines()]==[line.rsplit(';',1)[1] for line in retained.splitlines()],'Demangled allocation-row count changed')
 (ROOT/'independently-demangled-stacks.txt').write_text(demangle)
 owner=re.compile(r'(?<![A-Za-z0-9_.])SwiftJLS\.OwnedImageStorage(?:\.\(in _[0-9A-Fa-f]{32}\))?\.init\(')
 matches=[line for line in demangle.splitlines() if 'telemetryInjectedFrameCopy' in line and owner.search(line) and 'Swift.Array.init(repeating:' in line]
 retained_matches=[line for line in retained.splitlines() if 'telemetryInjectedFrameCopy' in line and owner.search(line) and 'Swift.Array.init(repeating:' in line]
 check(matches==retained_matches,'Injected allocation frames differ between CI and independent demangling')
 allocations=sum(int(line.rsplit(';',1)[1]) for line in matches)
 check(allocations==10 and 'telemetryInjectedFrameCopy' in (p/'mutant/analysis-demangled.txt').read_text().split('PEAK MEMORY CONSUMERS',1)[0],'Injected array allocation evidence missing')
 stdout=(p/'mutant/consumer.stdout').read_text();start=stdout.index('[\n');consumer=json.JSONDecoder().raw_decode(stdout[start:])[0]
 check([(x['bits'],x['samplesChecked'],x['width'],x['height']) for x in consumer]==[(12,2553,37,23),(16,2553,37,23)],'Mutation consumer sample evidence differs')
 check(d['detected'] and d['injected_sample_array_allocations']==10 and d['mutant_consumer_passed'] and not d['baseline_has_injected_allocator'],'Mutation summary differs')
 check('telemetryInjectedFrameCopy' not in original,'Injection present in committed production source')
 report['copy_mutation']={'fresh_build_and_trace_passed':True,'source_and_mutant_sha256_verified':True,'source_sha256':d['source_sha256'],'mutant_sha256':d['mutated_sha256'],'actual_injected_UInt8_array_allocations':allocations,'matching_stack_rows':len(matches),'independent_host_demangle_sha256':sha(demangle.encode()),'independent_vs_CI_demangle_different_rows':sum(a!=b for a,b in zip(demangle.splitlines(),retained.splitlines())),'injected_stack_rows_identical':True,'sample_identity_consumer_passed':True,'sample_cases':consumer,'heap_profile_sha256':trace['profile_sha256'],'committed_classifier_sha256':sha(source.encode()),'scope':'Injected-copy control sensitivity, not production copy-byte measurement. Baseline absence is the executed harness assertion; this requested artifact set does not contain the separate baseline trace.'}
 report.update(status='passed_independent_final_ci_artifact_audit',release_ready=False)
except BaseException as error:
 report['status']='failed';report['discrepancies'].append(repr(error))
 raise
finally:
 output=ROOT/'independent-final-ci-audit.json'
 with output.open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'preparation_variants':len(report['preparation']),'copy_allocations':report.get('copy_mutation',{}).get('actual_injected_UInt8_array_allocations'),'receipt':str(output)}))
