// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "ReleaseConsumer", platforms: [.macOS(.v26)],
dependencies: [.package(url: "https://github.com/raster-labs/SwiftJLS.git", revision: "c843b44e5f004be97b17663010d0cc369026d704")],
targets: [.executableTarget(name: "Consumer", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")]),
.executableTarget(name: "ReadmeExample", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")]),
.executableTarget(name: "MigrationExample", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")])], swiftLanguageModes: [.v6])
