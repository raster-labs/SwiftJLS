// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "ReleaseConsumer", platforms: [.macOS(.v26)],
dependencies: [.package(url: "https://github.com/raster-labs/SwiftJLS.git", revision: "69f31fe8bf79ba679df6482ea9c2b78572a89751")],
targets: [.executableTarget(name: "Consumer", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")]),
.executableTarget(name: "ReadmeExample", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")]),
.executableTarget(name: "MigrationExample", dependencies: [.product(name: "SwiftJLS", package: "SwiftJLS")])], swiftLanguageModes: [.v6])
