SDK_PATH=$(xcrun --sdk "$SDK_NAME" --show-sdk-path)
BIN_DIR=$(swift build --package-path Examples/AppleRuntimeConsumer -c release --triple "$TARGET_TRIPLE" --sdk "$SDK_PATH" --show-bin-path)
if [ "$SDK_NAME" = xrsimulator ]; then
  # Record the SwiftPM XR failure rather than calling its output a
  # runtime pass: it produced a 26.26.0 minimum and ELF linker flags.
  # Compile/link the exact package library sources with the explicit
  # Swift driver and SDK at the actual 26.0 deployment target.
  BIN_DIR="$RUNNER_TEMP/xr-runtime"
  mkdir -p "$BIN_DIR"
  SWIFTJLS_SOURCES=()
  while IFS= read -r SWIFTJLS_SOURCE; do SWIFTJLS_SOURCES+=("$SWIFTJLS_SOURCE"); done < <(find Sources/SwiftJLS -type f -name '*.swift' | LC_ALL=C sort)
  xcrun swiftc -O -swift-version 6 -strict-concurrency=complete -parse-as-library -emit-library -emit-module -module-name SwiftJLS -target "$TARGET_TRIPLE" -sdk "$SDK_PATH" "${SWIFTJLS_SOURCES[@]}" -emit-module-path "$BIN_DIR/SwiftJLS.swiftmodule" -Xlinker -install_name -Xlinker @rpath/libSwiftJLS.dylib -o "$BIN_DIR/libSwiftJLS.dylib"
  printf '%s\n' 'import SwiftJLS' 'let decoder = SwiftJLS.QualifiedMonochromeDecoder(profile: .jlswift0101)' | xcrun swiftc -typecheck -swift-version 6 -strict-concurrency=complete -target "$TARGET_TRIPLE" -sdk "$SDK_PATH" -I "$BIN_DIR" -
  codesign --force --sign - "$BIN_DIR/libSwiftJLS.dylib"
  xcrun swiftc -O -swift-version 6 -target "$TARGET_TRIPLE" -sdk "$SDK_PATH" -I "$BIN_DIR" -L "$BIN_DIR" -lSwiftJLS -Xlinker -rpath -Xlinker "$BIN_DIR" Examples/AppleRuntimeConsumer/Sources/AppleRuntimeConsumer/main.swift -o "$BIN_DIR/AppleRuntimeConsumer"
else
  swift build --package-path Examples/AppleRuntimeConsumer -c release --product AppleRuntimeConsumer --triple "$TARGET_TRIPLE" --sdk "$SDK_PATH"
fi
codesign --force --sign - "$BIN_DIR/AppleRuntimeConsumer"
echo "RUNTIME_BINARY=$BIN_DIR/AppleRuntimeConsumer" >> "$GITHUB_ENV"
