import SwiftJLS
let decoder = SwiftJLS.QualifiedMonochromeDecoder(profile: .jlswift0101)
let workspaceBytes: Int = SwiftJLS.QualifiedMonochromeDecoder.workspaceByteCount
