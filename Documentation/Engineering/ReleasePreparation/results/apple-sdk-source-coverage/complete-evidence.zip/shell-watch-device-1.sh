swift --version
xcodebuild -version
SDK_PATH=$(xcrun --sdk watchos --show-sdk-path)
echo 'public func platformIntBytes() -> Int { MemoryLayout<Int>.size }' > /tmp/IntWidth.swift
xcrun swiftc -O -emit-ir -parse-as-library -target arm64_32-apple-watchos26.0 -sdk "$SDK_PATH" /tmp/IntWidth.swift -o word-width.ll
SWIFTJLS_SOURCES=()
while IFS= read -r SWIFTJLS_SOURCE; do SWIFTJLS_SOURCES+=("$SWIFTJLS_SOURCE"); done < <(find Sources/SwiftJLS -type f -name '*.swift' | LC_ALL=C sort)
xcrun swiftc -O -swift-version 6 -strict-concurrency=complete -parse-as-library -emit-library -emit-module -module-name SwiftJLS -target arm64_32-apple-watchos26.0 -sdk "$SDK_PATH" "${SWIFTJLS_SOURCES[@]}" -emit-module-path /tmp/SwiftJLS.swiftmodule -o /tmp/libSwiftJLS.dylib
printf '%s\n' 'import SwiftJLS' 'let decoder = SwiftJLS.QualifiedMonochromeDecoder(profile: .jlswift0101)' | xcrun swiftc -typecheck -swift-version 6 -strict-concurrency=complete -target arm64_32-apple-watchos26.0 -sdk "$SDK_PATH" -I /tmp -
